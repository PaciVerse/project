-- Names: Byiringiro Pacifique
-- REGNUMBER 2409001187
-- Title of project: Sports League Management System
-- Create the database
CREATE DATABASE Sports_League_Management;
-- Use the database
USE Sports_League_Management;
show tables;
-- Create the Teams table

-- Physical Data Model (PDM)
CREATE TABLE Teams (
    Team_ID INT PRIMARY KEY,              -- Primary Key
    Team_Name VARCHAR(100),               -- Name of the team
    Coach_Name VARCHAR(100),              -- Name of the coach
    Home_Stadium VARCHAR(100)             -- Home stadium of the team
);
-- Create the Players table
CREATE TABLE Players (
    Player_ID INT PRIMARY KEY,            -- Primary Key
    Player_Name VARCHAR(100),             -- Name of the player
    Team_ID INT,                          -- Foreign Key referencing Teams
    Position VARCHAR(50),                 -- Position of the player in the team
    Age INT,                              -- Age of the player
    Nationality VARCHAR(50),              -- Nationality of the player
    FOREIGN KEY (Team_ID) REFERENCES Teams(Team_ID)  -- Foreign Key constraint
);
-- Create the Matches table
CREATE TABLE Matches (
    Match_ID INT PRIMARY KEY,             -- Primary Key
    Home_Team INT,                        -- Foreign Key referencing Teams as Home Team
    Away_Team INT,                        -- Foreign Key referencing Teams as Away Team
    Match_Date DATE,                      -- Date of the match
    Home_Score INT,                       -- Score of the home team
    Away_Score INT,                       -- Score of the away team
    FOREIGN KEY (Home_Team) REFERENCES Teams(Team_ID),  -- Foreign Key constraint
    FOREIGN KEY (Away_Team) REFERENCES Teams(Team_ID)   -- Foreign Key constraint
);

-- Names: Byiringiro Pacifique
-- REGNUMBER 2409001187

-- SQL for each table including CRUD operations and COUNT, AVG, SUM
-- INSERT Operation
INSERT INTO Teams (Team_ID, Team_Name, Coach_Name, Home_Stadium) 
VALUES (1, 'Team A', 'Coach A', 'Stadium A');
-- Select operation
SELECT * FROM Teams;
-- Update operation
UPDATE Teams 
SET Coach_Name = 'New Coach A' 
WHERE Team_ID = 1;
-- Delete operation
DELETE FROM Teams 
WHERE Team_ID = 1;
-- Aggregate Functions
-- COUNT
SELECT COUNT(*) FROM Teams;

-- Players Table
-- INSERT Operation
INSERT INTO Players (Player_ID, Player_Name, Team_ID, Position, Age, Nationality) 
VALUES (1, 'Player A', 1, 'Forward', 25, 'Country A');
-- Select operation
SELECT * FROM Players;
-- Update operation
UPDATE Players 
SET Position = 'Midfielder' 
WHERE Player_ID = 1;
-- Delete operation
DELETE FROM Players 
WHERE Player_ID = 1;
-- Aggregate Functions
-- COUNT
SELECT COUNT(*) FROM Players;

-- Matches Table
-- INSERT Operation
INSERT INTO Matches (Match_ID, Home_Team, Away_Team, Match_Date, Home_Score, Away_Score) 
VALUES (1, 1, 2, '2025-01-01', 3, 2);
-- Select operation
SELECT * FROM Matches;
-- Update operation
UPDATE Matches 
SET Home_Score = 4 
WHERE Match_ID = 1;
-- Delete operation
DELETE FROM Matches 
WHERE Match_ID = 1;
-- Aggregate Functions
-- COUNT
SELECT COUNT(*) FROM Matches;
-- Average operation
SELECT AVG(Home_Score) FROM Matches;
-- Sum operation
SELECT SUM(Home_Score) FROM Matches;

-- Names: Byiringiro Pacifique
-- REGNUMBER 2409001187

-- PL/SQL six different views

-- 1. View for Team and Coach Information
CREATE VIEW TeamCoachInfo AS
SELECT 
    Team_ID,
    Team_Name,
    Coach_Name,
    Home_Stadium
FROM 
    Teams;

-- 2. View for Players and Their Teams
CREATE VIEW PlayerTeamInfo AS
SELECT 
    Players.Player_ID,
    Players.Player_Name,
    Teams.Team_Name,
    Players.Position,
    Players.Age,
    Players.Nationality
FROM 
    Players
JOIN 
    Teams ON Players.Team_ID = Teams.Team_ID;

-- 3. View for Match Results
CREATE VIEW MatchResults AS
SELECT 
    Matches.Match_ID,
    HomeTeam.Team_Name AS Home_Team,
    AwayTeam.Team_Name AS Away_Team,
    Matches.Match_Date,
    Matches.Home_Score,
    Matches.Away_Score
FROM 
    Matches
JOIN 
    Teams AS HomeTeam ON Matches.Home_Team = HomeTeam.Team_ID
JOIN 
    Teams AS AwayTeam ON Matches.Away_Team = AwayTeam.Team_ID;

-- 4. View for Players by Age
CREATE VIEW PlayersByAge AS
SELECT 
    Player_ID,
    Player_Name,
    Team_ID,
    Age
FROM 
    Players
ORDER BY 
    Age DESC;

-- 5. View for Matches on Specific Date
CREATE VIEW MatchesOnDate AS
SELECT 
    Match_ID,
    Home_Team,
    Away_Team,
    Match_Date,
    Home_Score,
    Away_Score
FROM 
    Matches
WHERE 
    Match_Date = '2025-01-01';

-- 6. View for Top Scoring Matches
CREATE VIEW TopScoringMatches AS
SELECT 
    Match_ID,
    Home_Team,
    Away_Team,
    Match_Date,
    (Home_Score + Away_Score) AS Total_Score
FROM 
    Matches
ORDER BY 
    Total_Score DESC;
    
    -- Names: Byiringiro Pacifique
-- REGNUMBER 2409001187

-- Six different stored procedures
-- 1. Add a New Team
DELIMITER //

CREATE PROCEDURE AddTeam (
    p_Team_ID INT,
    p_Team_Name VARCHAR(100),
    p_Coach_Name VARCHAR(100),
    p_Home_Stadium VARCHAR(100)
)
BEGIN
    INSERT INTO Teams (Team_ID, Team_Name, Coach_Name, Home_Stadium) 
    VALUES (1, 'Team A', 'John Smith', 'Stadium A');
END //

DELIMITER ;

-- 2. Add a New Player
DELIMITER //

CREATE PROCEDURE AddPlayer (
    p_Player_ID INT,
    p_Player_Name VARCHAR(100),
    p_Team_ID INT,
    p_Position VARCHAR(50),
    p_Age INT,
    p_Nationality VARCHAR(50)
)
BEGIN
    INSERT INTO Players (Player_ID, Player_Name, Team_ID, Position, Age, Nationality) 
    VALUES (1, 'Alice Johnson', 1, 'Forward', 24, 'USA');
END //

DELIMITER ;

-- 3. Add a New Match
DELIMITER //

CREATE PROCEDURE AddMatch (
    p_Match_ID INT,
    p_Home_Team INT,
    p_Away_Team INT,
    p_Match_Date DATE,
    p_Home_Score INT,
    p_Away_Score INT
)
BEGIN
    INSERT INTO Matches (Match_ID, Home_Team, Away_Team, Match_Date, Home_Score, Away_Score) 
    VALUES (1, 1, 2, '2025-01-15', 3, 2);
END //

DELIMITER ;

-- 4. Update Team Information
DELIMITER //

CREATE PROCEDURE UpdateTeam (
    p_Team_ID INT,
    p_Team_Name VARCHAR(100),
    p_Coach_Name VARCHAR(100),
    p_Home_Stadium VARCHAR(100)
)
BEGIN
    UPDATE Teams 
    SET Team_Name = p_Team_Name, Coach_Name = p_Coach_Name, Home_Stadium = p_Home_Stadium 
    WHERE Team_ID = p_Team_ID;
END //

DELIMITER ;
CALL UpdateTeam(1, 'Team A', 'New Coach A', 'New Stadium A');

-- 5. Update Player Information
DELIMITER //

CREATE PROCEDURE UpdatePlayer (
    p_Player_ID INT,
    p_Player_Name VARCHAR(100),
    p_Team_ID INT,
    p_Position VARCHAR(50),
    p_Age INT,
    p_Nationality VARCHAR(50)
)
BEGIN
    UPDATE Players 
    SET Player_Name = p_Player_Name, Team_ID = p_Team_ID, Position = p_Position, Age = p_Age, Nationality = p_Nationality 
    WHERE Player_ID = p_Player_ID;
END //

DELIMITER ;
CALL UpdatePlayer(1, 'Alice Johnson', 1, 'Forward', 24, 'USA');

-- 6. Update Match Score
DELIMITER //

CREATE PROCEDURE UpdateMatchScore (
    Match_ID INT,
    p_Home_Score INT,
    p_Away_Score INT
)
BEGIN
    UPDATE Matches 
    SET Home_Score = p_Home_Score, Away_Score = p_Away_Score 
    WHERE Match_ID = p_Match_ID;
END //

DELIMITER ;
CALL UpdateMatchScore(1, 3, 2);

-- Names: Byiringiro Pacifique
-- REGNUMBER 2409001187

CREATE TABLE Match_Log (
    Log_ID INT AUTO_INCREMENT PRIMARY KEY,
    Action VARCHAR(50),
    Match_ID INT,
    Action_Date DATETIME
);

-- TRIGGERS
-- Teams Table Triggers
-- After Insert
DELIMITER //

CREATE TRIGGER after_team_insert
AFTER INSERT ON Teams
FOR EACH ROW
BEGIN
    INSERT INTO Team_Log (Action, Team_ID, Action_Date)
    VALUES ('INSERT', NEW.Team_ID, NOW());
END //

DELIMITER ;

-- After Update
DELIMITER //

CREATE TRIGGER after_team_update
AFTER UPDATE ON Teams
FOR EACH ROW
BEGIN
    INSERT INTO Team_Log (Action, Team_ID, Action_Date)
    VALUES ('UPDATE', NEW.Team_ID, NOW());
END //

DELIMITER ;

-- After Delete
DELIMITER //

CREATE TRIGGER after_team_delete
AFTER DELETE ON Teams
FOR EACH ROW
BEGIN
    INSERT INTO Team_Log (Action, Team_ID, Action_Date)
    VALUES ('DELETE', OLD.Team_ID, NOW());
END //

DELIMITER ;

-- Players Table Triggers
-- After Insert
DELIMITER //

CREATE TRIGGER after_player_insert
AFTER INSERT ON Players
FOR EACH ROW
BEGIN
    INSERT INTO Player_Log (Action, Player_ID, Action_Date)
    VALUES ('INSERT', NEW.Player_ID, NOW());
END //

DELIMITER ;

-- After Update
DELIMITER //

CREATE TRIGGER after_player_update
AFTER UPDATE ON Players
FOR EACH ROW
BEGIN
    INSERT INTO Player_Log (Action, Player_ID, Action_Date)
    VALUES ('UPDATE', NEW.Player_ID, NOW());
END //

DELIMITER ;

-- After Delete
DELIMITER //

CREATE TRIGGER after_player_delete
AFTER DELETE ON Players
FOR EACH ROW
BEGIN
    INSERT INTO Player_Log (Action, Player_ID, Action_Date)
    VALUES ('DELETE', OLD.Player_ID, NOW());
END //

DELIMITER ;

-- Matches Table Triggers
-- After Insert
DELIMITER //

CREATE TRIGGER after_match_insert
AFTER INSERT ON Matches
FOR EACH ROW
BEGIN
    INSERT INTO Match_Log (Action, Match_ID, Action_Date)
    VALUES ('INSERT', NEW.Match_ID, NOW());
END //

DELIMITER ;

-- After Update
DELIMITER //

CREATE TRIGGER after_match_update
AFTER UPDATE ON Matches
FOR EACH ROW
BEGIN
    INSERT INTO Match_Log (Action, Match_ID, Action_Date)
    VALUES ('UPDATE', NEW.Match_ID, NOW());
END //

DELIMITER ;

-- After Delete
DELIMITER //

CREATE TRIGGER after_match_delete
AFTER DELETE ON Matches
FOR EACH ROW
BEGIN
    INSERT INTO Match_Log (Action, Match_ID, Action_Date)
    VALUES ('DELETE', OLD.Match_ID, NOW());
END //

DELIMITER ;

-- Names: Byiringiro Pacifique
-- REGNUMBER 2409001187

-- Creating Users and Granting Permissions
CREATE USER 'league_leader'@'localhost' IDENTIFIED BY 'leader123';
-- Granting All Privileges on All Tables
GRANT ALL PRIVILEGES ON Sports_League_Management.* TO 'league_leader'@'localhost';
-- Granting Specific Privileges on Specific Tables
GRANT SELECT, INSERT, UPDATE, DELETE ON Sports_League_Management.Teams TO 'league_leader'@'localhost';
-- Granting Administrative Privileges
GRANT GRANT OPTION ON Sports_League_Management.* TO 'league_leader'@'localhost';

-- Revoking Permissions
-- Revoking Specific Privileges
REVOKE SELECT, INSERT, UPDATE, DELETE ON Sports_League_Management.Teams FROM 'league_leader'@'localhost';
-- Revoking All Privileges
REVOKE ALL PRIVILEGES ON Sports_League_Management.* FROM 'league_leader'@'localhost';


